import gdal
output = 'thaOut.tif'
raster = 'organic_30cm.tif'
bbox_tup = (97.34380713, 5.61285098, 105.63681192, 20.46483364)
dataset = gdal.Warp(output, raster, format='GTiff', outputBounds=bbox_tup)
del ds
print('ouput', output)
