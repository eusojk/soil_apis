soilapis
========

Utilities:
- extract the total available water (TAW) value from soil layers
- create appropriate dynamic or static soil database (.SOL) as an input for DSSAT 